@echo off
chcp 65001 >nul
rem Cree sur le Bureau un raccourci vers l'application, avec son icone.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=Split-Path -Parent '%~f0';$p=Get-ChildItem -LiteralPath $h -Filter 'NDAP_SUKULU_*.html' | Select-Object -First 1;$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'NDAP SUKULU - GES4062.lnk'));$s.TargetPath=$p.FullName;$s.WorkingDirectory=$h;$s.IconLocation=(Join-Path $h 'img\icone.ico')+',0';$s.Description='NDAP SUKULU GES4062';$s.Save();Write-Host 'Raccourci cree sur le Bureau :' 'NDAP SUKULU - GES4062'"
timeout /t 4 >nul
